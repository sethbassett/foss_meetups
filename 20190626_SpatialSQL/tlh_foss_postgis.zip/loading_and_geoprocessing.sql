/*

Name:			test_drive.sql
Created by:		Linc Clay, The GIS Shop, INC.
Created on:		06/01/2019

Purpose: The statements below are used for the FOSS PostGIS
'Test Drive' (aka tutorial) portion of the meeting.

The approach will be to copy a statement and paste it into
pgAdmin 4 to execute.  After each execution, we will used
either gpAdmin 4 or QGIS to look at the results.

Revision History -

06/02/19 - Added better descriptions to geoprocessing section,
added several more spatial join examples.

Notes - 

- DO NOT run this entire file at once.  That will defeat the purpose.

- While in the FL Albers projection, all the points are near 
the origin (in the middle of the Gulf).

*/

-- First stop - some constructors.

-- Create a point table in the FL Albers HARN projection.
CREATE TABLE coffee
(gid SERIAL, name VARCHAR(20), geom GEOMETRY(POINT, 3087));

-- Load some points into the empty table.
INSERT INTO coffee (name, geom) VALUES 
('Black Dog #1', ST_GeomFromText('POINT(65 95)', 3087)),
('Black Dog #2', ST_GeomFromText('POINT(10 10)', 3087)),
('Catalina #1', ST_GeomFromText('POINT(10 15)', 3087)),
('Catalina #2', ST_GeomFromText('POINT(20 5)', 3087)),
('Lucky Goat #1', ST_GeomFromText('POINT(45 70)', 3087)),
('Lucky Goat #2', ST_GeomFromText('POINT(80 75)', 3087)),
('Power Plant', ST_GeomFromText('POINT(15 10)', 3087));

-- Create a line table.
CREATE TABLE trails
(gid SERIAL, name VARCHAR(20), geom GEOMETRY(LINESTRING, 3087));

-- Load some lines.
INSERT INTO trails (name, geom) VALUES
('St Marks', ST_GeomFromText('LINESTRING(1 1, 5 5, 9 9, 14 9, 50 50)', 3087)),
('Fern', ST_GeomFromText('LINESTRING(15 65, 95 65)', 3087)),
('Cadillac', ST_GeomFromText('LINESTRING(95 95, 95 5)', 3087));

-- Create a polygon table.
CREATE TABLE parks
(gid SERIAL, name VARCHAR(20), geom GEOMETRY(POLYGON, 3087));

-- Load some polygons.
INSERT INTO parks (name, geom) VALUES
('Cascades', ST_GeomFromText('POLYGON((13 8, 13 30, 50 30, 50 13, 13 8))', 3087)),
('Lake Ella', ST_GeomFromText('POLYGON((60 80, 60 90, 70 90, 70 80, 60 80), (62 82, 62 88, 68 88, 68 82, 62 82))', 3087)),
('Tom Brown', ST_GeomFromText('POLYGON((85 10, 85 90, 90 90, 90 10, 85 10))', 3087));

-- Next stop - a few accessors.

-- Some point accessors, with an output for display.
SELECT ST_AsText(geom) FROM coffee WHERE name = 'Black Dog #1';
SELECT ST_X(geom), ST_Y(geom) FROM coffee WHERE name = 'Black Dog #1';

-- Some line accessors, with an output for display.
SELECT ST_AsText(geom) FROM trails WHERE name = 'St Marks';
SELECT ST_NPoints(geom), ST_Length(geom) FROM trails WHERE name = 'St Marks';
SELECT ST_AsText(ST_EndPoint(geom)) FROM trails WHERE name = 'St Marks';

-- Some polygon accessors, with an output for display.
SELECT ST_AREA(geom) FROM parks WHERE name = 'Lake Ella';
SELECT ST_NRings(geom) FROM parks WHERE name = 'Lake Ella';
SELECT ST_Perimeter(geom) FROM parks WHERE name = 'Lake Ella';
SELECT ST_AsText(ST_ExteriorRing(geom)) FROM parks WHERE name = 'Lake Ella';

-- Another accessor.
SELECT ST_AsText(ST_Envelope(geom)) FROM trails WHERE name = 'St Marks';

-- Spatial relationships.

-- Find the closest coffee shop to Lake Ella.
SELECT coffee.name FROM coffee, parks
WHERE parks.name = 'Lake Ella'
ORDER BY ST_Distance(coffee.geom, parks.geom) ASC
LIMIT 1;

-- List is name and distance from Lake Ella for all coffee shops.
SELECT coffee.name, ST_DISTANCE(coffee.geom, parks.geom) 
FROM coffee, parks
WHERE parks.name = 'Lake Ella'
ORDER BY ST_Distance(coffee.geom, parks.geom) ASC;

-- List the trail name and park name where trails cross a park.
SELECT trails.name, parks.name FROM trails, parks
WHERE ST_Crosses(trails.geom, parks.geom)

-- Does the Fern trail touch the Cadillac trail?
SELECT ST_Touches(a.geom, b.geom)
FROM trails a, trails b
WHERE a.name = 'Fern' and b.name = 'Cadillac';

-- Does the Fern trail intersect the Cadillac trail?
SELECT ST_Intersects(a.geom, b.geom)
FROM trails a, trails b
WHERE a.name = 'Fern' and b.name = 'Cadillac';

-- Spatial joins.

-- List the coffee shops inside (within) a park.
SELECT coffee.name, park.name FROM coffee 
JOIN parks ON ST_Within(coffee.geom, parks.geom);

-- Another way to do the same thing.
SELECT coffee.name, parks.name from coffee, parks
WHERE ST_Within(coffee.geom, parks.geom);

-- List the names of trails and parks that intersect.
SELECT trails.name AS trail, parks.name AS park 
FROM trails
JOIN parks ON ST_Intersects(trails.geom, parks.geom);

-- List the trail name, park name, and trail length
-- where trails intersect parks.
SELECT trails.name, parks.name, ST_Length(trails.geom)
FROM trails, parks WHERE ST_Intersects(trails.geom, parks.geom);

-- Same as above, except only list the length within the park.
SELECT trails.name, parks.name, 
ST_Length(ST_Intersection(trails.geom, parks.geom))
FROM trails, parks WHERE ST_Intersects(trails.geom, parks.geom);

-- Geometry processing.

-- Create a 5 meter buffer on the St Marks trail
-- and add it to the parks table.
INSERT INTO parks (name, geom) SELECT
'St Marks Buff 5', ST_Buffer(trails.geom, 5)
FROM trails WHERE name = 'St Marks';

-- Create a poygon that is the intersection of
-- the 5-meter St Marks trail buffer and 
--  Cascades Park, then add it to the parks table.
INSERT INTO parks (name, geom) SELECT
'Intersect', ST_Intersection(a.geom, b.geom)
FROM parks a, parks b
WHERE a.name = 'St Marks Buff 5' 
AND b.name = 'Cascades';

-- Spatial operators.

-- Do the envelopes of St Marks  5-meter buffer
-- and Cascades Park intersect? Print the names
-- of each and true/false.
SELECT a.name, b.name, a.geom && b.geom
FROM  parks a, parks b
WHERE a.name = 'St Marks Buff 5'
AND b.name = 'Cascades';

-- What records in the parks table have overlapping
-- envelopes? List the names of the overlapping polygons.
SELECT a.name, b.name
FROM parks a
INNER JOIN parks b ON (a.geom && b.geom)
WHERE a.gid != b.gid;

-- What trail envelopes overlap park envelopes?
-- List the names of the overlapping records.
SELECT a.name, b.name
FROM parks a
INNER JOIN trails b ON (a.geom && b.geom);

-- Tell us if each coffee shop is to the left of
-- each park.  List the names of each and true/false.
SELECT a.name, b.name, a.geom << b.geom AS LEFT
FROM coffee a, parks b;








